Name: PICUT, JOHN ANDREI P. 
Student ID: 02-2425-012943


SPECIAL Slot Machine

Theme:
Fallout: SPECIAL Slot Machine

How to Run
1. Open index.html
2. Click START
3. Adjust your bet
4. Press SPIN

Features
- Random reel spinning
- Betting system
- Caps currency
- SPECIAL symbols
- Jackpot
- Responsive design
- Animated interface