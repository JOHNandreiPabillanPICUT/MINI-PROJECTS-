Name: PICUT, JOHN ANDREI P. 
Student ID: 02-2425-012943


Math for Kids

Theme:
Math with 4 amazing themes

How to Run
1. Open index.html
2. Click START
3. Choose a math op
4. Input a number in the question
5. Click "submit"


Core Features

5 Math Modes: Addition (+), Subtraction (−), Multiplication (×), Division (÷), and Random mode (🎲).

Kid-Friendly Math: Subtraction never gives negative numbers, and Division always gives simple whole numbers (no decimals).

3 Difficulty Levels: Easy (0–5), Medium (0–7), and Hard (0–10).

Score & Streak Tracker: Earn +10 points for every right answer and track your correct answer streak.

High Score Board: Saves your best score for each math mode.

Score Reset: Resets your score when you get an answer wrong or change modes to keep the high score accurate.

Not so Core Features

Color Feedback: The input box flashes Green for correct answers and Red for wrong ones.

Hint Button: Gives helpful tips on how to solve the active question.

4 Themes: Switch between Cats, Math, Night Time, and Starry Night styles.

Music and Sound Effects: Custom sounds for correct/wrong answers and background music (with On/Off toggle buttons).
