// List of all SPECIAL symbols and their rewards//
const symbols=[
{
name:"Strength",
image:"images/S.jfif",
reward:5
},
{
name:"Perception",
image:"images/P.jfif",
reward:10
},
{
name:"Endurance",
image:"images/Endurance.webp",
reward:15
},
{
name:"Charisma",
image:"images/c.jfif",
reward:20
},
{
name:"Intelligence",
image:"images/i.webp",
reward:25
},
{
name:"Agility",
image:"images/a.webp",
reward:30
},
{
name:"Luck",
image:"images/L.jfif",
reward:50
}
];

// NUMBER OF CAPS AVAILABLE//
let credits=500;
// NUMBER OF CAPS WILL BE BETTED UPON//
let bet=10;

// REELS 1 TO 3//
const r1=document.getElementById("r1");
const r2=document.getElementById("r2");
const r3=document.getElementById("r3");

//DISPLAYS AND UPDATES TEXT AND BETS//
const creditsText=document.getElementById("credits");
const betText=document.getElementById("bet");
const message=document.getElementById("message");

// BUTTONS //
const spinBtn=document.getElementById("spinBtn");
const plusBet=document.getElementById("plusBet");
const minusBet=document.getElementById("minusBet");

const specialCircles=document.querySelectorAll(".specialCircle");

// UPDATES CAPS OR BET VISUALS//
function updateUI(){
creditsText.textContent=credits;
betText.textContent=bet;

// CONTROLS BETS
plusBet.disabled=bet>=50;
minusBet.disabled=bet<=10;
//

spinBtn.disabled=credits<bet;
}

// Returns a random SPECIAL symbol//
function randomSymbol(){
return symbols[Math.floor(Math.random()*symbols.length)];
}

// Spins one reel for a certain duration//
function spinReel(element,time){

// RESULT
return new Promise(resolve=>{
//

// SPIN ANIMATION
element.classList.add("spin");
//

const interval=setInterval(()=>{

const symbol=randomSymbol();

element.src=symbol.image;
element.dataset.symbol=symbol.name;

},80);

setTimeout(()=>{

clearInterval(interval);

element.classList.remove("spin");

resolve(element.dataset.symbol);

},time);

});

}

async function spin(){

// BET CHECK IF SUFFICIENT IF NOT NO ROLL W/MSG
if(credits<bet){

message.textContent="Not enough Caps!";
return;
//
}
// REMOVE EFFECTS BEFORE ROLLING
clearGlow();
//

spinBtn.disabled=true;

credits-=bet;

updateUI();

message.textContent="Spinning...";

// SPIN ANIMATION
const a=spinReel(r1,1200);
const b=spinReel(r2,1700);
const c=spinReel(r3,2200);
//
const results=await Promise.all([a,b,c]);

checkWin(results);

updateUI();

}
// Checks whether the player has won//
function checkWin(result){

const[x,y,z]=result;

if(x===y&&y===z){

const symbol=symbols.find(s=>s.name===x);

const prize=bet*symbol.reward;

credits+=prize;

message.textContent=x+" JACKPOT! +"+prize+" Caps";

glowCircle(x);

}
// CHECKS IF TWO OF THREE REEL COLUMNS HAS THE SAME SYMBOL IF YES THEN PRIZE//
else if(x===y||y===z||x===z){

const prize=bet*2;

credits+=prize;

// MSG IF TWO SYMBOLS ARE PRESENT //
message.textContent="Two Matching SPECIAL! +"+prize+" Caps";

}

else{

message.textContent="Better luck next spin.";

}

updateUI();

}

function glowCircle(symbol){

clearGlow();

const map={
Strength:"S",
Perception:"P",
Endurance:"E",
Charisma:"C",
Intelligence:"I",
Agility:"A",
Luck:"L"
};

const target=map[symbol];

specialCircles.forEach(circle=>{

const letter=circle.querySelector("span").textContent;

if(letter===target){

circle.classList.add("active");

}

});

}

function clearGlow(){

specialCircles.forEach(circle=>{

circle.classList.remove("active");

});

}

plusBet.addEventListener("click",()=>{

if(bet<50){

bet+=10;

updateUI();

}

});

minusBet.addEventListener("click",()=>{

if(bet>10){

bet-=10;

updateUI();

}

});

spinBtn.addEventListener("click",spin);

const startScreen=document.getElementById("startScreen");
const gameScreen=document.getElementById("gameScreen");
const startBtn=document.getElementById("startBtn");

gameScreen.style.display="none";

startBtn.addEventListener("click",()=>{

startScreen.style.display="none";

gameScreen.style.display="flex";

updateUI();

});

updateUI();