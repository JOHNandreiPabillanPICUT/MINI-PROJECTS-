let currentOp = 'plus'; //current mode active
let activeOp = 'plus'; // Current mode active for questioning
let currentDiff = 'easy'; // Current diff
let score = 0; // Current score
let streak = 0; // current streak
let num1 = 0;
let num2 = 0;
let correctAnswer = 0;
let isAnswerLocked = false; // locks user to spam answers

// High scores
const highScores = {
  plus: 0,
  minus: 0,
  times: 0,
  divide: 0,
  random: 0
};

// User Interface Elements
const startScreen = document.getElementById('start-screen');
const gameContainer = document.getElementById('game-container');
const startBtn = document.getElementById('start-btn');
const exitBtn = document.getElementById('exit-btn');

const scoreVal = document.getElementById('score-val');
const streakVal = document.getElementById('streak-val');
const problemText = document.getElementById('problem-text');
const answerInput = document.getElementById('answer-input');
const hintText = document.getElementById('hint-text');

const submitBtn = document.getElementById('submit-btn');
const nextBtn = document.getElementById('next-btn');
const hintBtn = document.getElementById('hint-btn');

const opButtons = document.querySelectorAll('.op-btn');
const diffButtons = document.querySelectorAll('.diff-btn');
const themeButtons = document.querySelectorAll('.theme-btn');

const hsLabel = document.getElementById('hs-label');
const hsScore = document.getElementById('hs-score');

const bgMusic = document.getElementById('bg-music');
const correctSound = document.getElementById('correct-sound');
const wrongSound = document.getElementById('wrong-sound');

const musicBtn = document.getElementById('toggle-music-btn');
const sfxBtn = document.getElementById('toggle-sfx-btn');

let isMusicOn = false;
let isSfxOn = true;


function playCorrectSound() {
  if (isSfxOn && correctSound) {
    correctSound.currentTime = 0;
    correctSound.play().catch(err => console.log('Audio playback prevented:', err));
  }
}

function playWrongSound() {
  if (isSfxOn && wrongSound) {
    wrongSound.currentTime = 0;
    wrongSound.play().catch(err => console.log('Audio playback prevented:', err));
  }
}

// Returns chosen difficulty
function getRangeByDifficulty(difficulty) {
  switch (difficulty) {
    case 'easy':
      return { min: 0, max: 5 };
    case 'medium':
      return { min: 0, max: 7 };
    case 'hard':
      return { min: 0, max: 10 };
    default:
      return { min: 0, max: 5 };
  }
}

//generates a random number (random numbers is also based on the current difficulty so 6-10 isnt available in easy)
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// display for math ops symbols (plus is +)
function getOpSymbol(op) {
  switch (op) {
    case 'plus': return '+';
    case 'minus': return '-';
    case 'times': return '×';
    case 'divide': return '÷';
    default: return '+';
  }
}

function generateProblem() {
  isAnswerLocked = false; // stops player from spamming answers
  const range = getRangeByDifficulty(currentDiff);

// chooses a random math op
  if (currentOp === 'random') {
    const ops = ['plus', 'minus', 'times', 'divide'];
    activeOp = ops[Math.floor(Math.random() * ops.length)];
  } else {
    activeOp = currentOp;
  }

  answerInput.value = '';
  hintText.textContent = '';
  answerInput.style.backgroundColor = '#111111';
  answerInput.style.color = '#ffffff';
  problemText.style.color = 'black';
  answerInput.focus();



  // displays the number and calculates the correct answer
  if (activeOp === 'plus') {
    num1 = getRandomInt(range.min, range.max); // 1
    num2 = getRandomInt(range.min, range.max); // 2
    correctAnswer = num1 + num2; // answer 1 + 2 = 3

  } else if (activeOp === 'minus') {
    num1 = getRandomInt(range.min, range.max);
    num2 = getRandomInt(range.min, range.max);
    if (num1 < num2) {
      [num1, num2] = [num2, num1];
    }
    correctAnswer = num1 - num2;

  } else if (activeOp === 'times') {
    num1 = getRandomInt(range.min, range.max);
    num2 = getRandomInt(range.min, range.max);
    correctAnswer = num1 * num2;

  } else if (activeOp === 'divide') {
    num2 = getRandomInt(1, Math.max(1, range.max));
    correctAnswer = getRandomInt(1, range.max);
    num1 = num2 * correctAnswer;
  }

  // displays the math problem for the user to see
  const symbol = getOpSymbol(activeOp);
  problemText.textContent = `${num1} ${symbol} ${num2} = ?`;
}

function checkAnswer() {
  if (isAnswerLocked) return;

  const userVal = answerInput.value.trim();
  if (userVal === '') return;

  const userAns = Number(userVal);

  hintText.textContent = '';

  if (userAns === correctAnswer) {
    isAnswerLocked = true;
    score += 10;
    streak += 1;
    
    answerInput.style.backgroundColor = '#2ed573';
    answerInput.style.color = '#ffffff';
    
    playCorrectSound();

    //Update highScore if score is higher than the old score
    if (score > highScores[currentOp]) {
      highScores[currentOp] = score;
      updateHighScoreDisplay();
    }

    setTimeout(() => {
      generateProblem();
    }, 1000);

  } else {
    // Reset current run score & streak on a wrong answer
    score = 0;
    streak = 0;
    
    answerInput.style.backgroundColor = '#ff4757';
    answerInput.style.color = '#ffffff';

    // Play wrong sound effect
    playWrongSound();
  }

  updateStats();
}

//Show hint on current math problem
function showHint() {
  if (activeOp === 'plus') {
    hintText.textContent = `💡 Count ${num2} more starting from ${num1}.`;
  } else if (activeOp === 'minus') {
    hintText.textContent = `💡 If you take ${num2} away from ${num1}, what's left?`;
  } else if (activeOp === 'times') {
    if (num1 === 0 || num2 === 0) {
      hintText.textContent = `💡 Anything multiplied by 0 is 0.`;
    } else {
      hintText.textContent = `💡 Add ${num1} together ${num2} times.`;
    }
  } else if (activeOp === 'divide') {
    hintText.textContent = `💡 How many groups of ${num2} fit into ${num1}?`;
  }
  hintText.style.color = '#555';
}

// UPDATES current streak and score if the user gets the answer wrong the score and streak resets or updates to ZERO. 
function updateStats() {
  scoreVal.textContent = score;
  streakVal.textContent = streak;
}

// IF THE SCORE IS HIGHER THAN THE HIGHSCORE IT UPDATES THE HIGHSSCORE
function updateHighScoreDisplay() {
  hsLabel.textContent = `${currentOp.toUpperCase()}:`;
  hsScore.textContent = highScores[currentOp];
}

function setTheme(themeClass) {
  document.body.className = '';
  if (themeClass) {
    document.body.classList.add(themeClass);
  }
}


submitBtn.addEventListener('click', checkAnswer);
nextBtn.addEventListener('click', generateProblem);
hintBtn.addEventListener('click', showHint);

answerInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    checkAnswer();
  }
});

opButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    opButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    currentOp = btn.getAttribute('data-op');
    
    // Reset current score and streak when switching operations
    score = 0;
    streak = 0;
    updateStats();
    
    updateHighScoreDisplay();
    generateProblem();
  });
});

diffButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    diffButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    currentDiff = btn.getAttribute('data-diff');
    generateProblem();
  });
});

themeButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    themeButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    const selectedTheme = btn.getAttribute('data-theme');
    setTheme(selectedTheme);
  });
});

startBtn.addEventListener('click', () => {
  
  if (correctSound) correctSound.load();
  if (wrongSound) wrongSound.load();

  startScreen.classList.add('hidden');
  gameContainer.classList.remove('hidden');
  
  // Reset score stats on game start
  score = 0;
  streak = 0;
  updateStats();

  generateProblem();
});

exitBtn.addEventListener('click', () => {
  gameContainer.classList.add('hidden');
  startScreen.classList.remove('hidden');
  
  // Reset score stats if break button is clicked
  score = 0;
  streak = 0;
  updateStats();

  if (isMusicOn && bgMusic) {
    bgMusic.pause();
    isMusicOn = false;
    if (musicBtn) {
      musicBtn.textContent = '🎵 Music: Off';
      musicBtn.classList.remove('active');
    }
  }
});


if (musicBtn) {
  musicBtn.addEventListener('click', () => {
    isMusicOn = !isMusicOn;
    if (isMusicOn && bgMusic) {
      bgMusic.play().catch(err => console.log('Autoplay prevented:', err));
      musicBtn.textContent = '🎵 Music: On';
      musicBtn.classList.add('active');
    } else if (bgMusic) {
      bgMusic.pause();
      musicBtn.textContent = '🎵 Music: Off';
      musicBtn.classList.remove('active');
    }
  });
}

if (sfxBtn) {
  sfxBtn.addEventListener('click', () => {
    isSfxOn = !isSfxOn;
    sfxBtn.textContent = isSfxOn ? '🔊 SFX: On' : '🔇 SFX: Off';
    sfxBtn.classList.toggle('active', isSfxOn);
  });
}


updateHighScoreDisplay();
generateProblem();