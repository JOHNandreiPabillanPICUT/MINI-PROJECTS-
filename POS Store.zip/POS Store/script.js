// DATA AND STATE VARIABLES
// Product catalog database categorized by food types
const groceryItems = [
    // Snacks
    { product_id: 1, product_name: "Dried Mangoes (200g)", product_price: 180, category: "Snacks" },
    { product_id: 2, product_name: "Banana Chips (200g)", product_price: 120, category: "Snacks" },
    { product_id: 6, product_name: "Peanut Brittle (200g)", product_price: 150, category: "Snacks" },
    { product_id: 7, product_name: "Cashew Nuts (250g)", product_price: 280, category: "Snacks" },
    { product_id: 12, product_name: "Rice Crackers (200g)", product_price: 100, category: "Snacks" },
    { product_id: 16, product_name: "Chicharon (100g)", product_price: 120, category: "Snacks" },
    { product_id: 43, product_name: "Native Peanuts (250g)", product_price: 100, category: "Snacks" },

    // Beverages
    { product_id: 3, product_name: "Tablea Chocolate (250g)", product_price: 200, category: "Beverages" },
    { product_id: 8, product_name: "Philippine Coffee Beans (250g)", product_price: 320, category: "Beverages" },
    { product_id: 20, product_name: "Corn Coffee (250g)", product_price: 150, category: "Beverages" },
    { product_id: 21, product_name: "Coconut Water (1L)", product_price: 100, category: "Beverages" },
    { product_id: 22, product_name: "Calamansi Juice (1L)", product_price: 120, category: "Beverages" },
    { product_id: 50, product_name: "Native Chocolate Drink (Sikwate, 250ml)", product_price: 90, category: "Beverages" },

    // Cooking and Staples
    { product_id: 4, product_name: "Coconut Oil (500ml)", product_price: 180, category: "Cooking & Staples" },
    { product_id: 9, product_name: "Native Vinegar (500ml)", product_price: 120, category: "Cooking & Staples" },
    { product_id: 11, product_name: "Coconut Sugar (500g)", product_price: 180, category: "Cooking & Staples" },
    { product_id: 18, product_name: "Native Brown Rice (1kg)", product_price: 90, category: "Cooking & Staples" },
    { product_id: 19, product_name: "White Rice (1kg)", product_price: 70, category: "Cooking & Staples" },
    { product_id: 24, product_name: "Bagoong (250g)", product_price: 90, category: "Cooking & Staples" },
    { product_id: 25, product_name: "Fish Sauce (Patis, 500ml)", product_price: 110, category: "Cooking & Staples" },
    { product_id: 26, product_name: "Soy Sauce (500ml)", product_price: 95, category: "Cooking & Staples" },
    { product_id: 27, product_name: "Native Salt (250g)", product_price: 50, category: "Cooking & Staples" },
    { product_id: 28, product_name: "Coconut Milk Powder (200g)", product_price: 140, category: "Cooking & Staples" },

    // Pantry and Bakery
    { product_id: 5, product_name: "Mango Jam (250g)", product_price: 160, category: "Pantry & Bakery" },
    { product_id: 10, product_name: "Philippine Honey (250ml)", product_price: 250, category: "Pantry & Bakery" },
    { product_id: 17, product_name: "Pandesal Pack (12 pcs)", product_price: 80, category: "Pantry & Bakery" },
    { product_id: 23, product_name: "Guava Jelly (250g)", product_price: 160, category: "Pantry & Bakery" },
    { product_id: 29, product_name: "Instant Noodles (Pack of 6)", product_price: 75, category: "Pantry & Bakery" },

    // Fresh and Frozen
    { product_id: 13, product_name: "Salted Fish (Danggit, 250g)", product_price: 220, category: "Fresh & Frozen" },
    { product_id: 14, product_name: "Longganisa (Frozen, 500g)", product_price: 280, category: "Fresh & Frozen" },
    { product_id: 15, product_name: "Tocino (Frozen, 500g)", product_price: 300, category: "Fresh & Frozen" },
    { product_id: 30, product_name: "Native Cheese (Kesong Puti, 250g)", product_price: 180, category: "Fresh & Frozen" },
    { product_id: 31, product_name: "Eggs (Dozen)", product_price: 90, category: "Fresh & Frozen" },
    { product_id: 32, product_name: "Fresh Tilapia (1kg)", product_price: 160, category: "Fresh & Frozen" },
    { product_id: 33, product_name: "Fresh Bangus (1kg)", product_price: 180, category: "Fresh & Frozen" },
    { product_id: 34, product_name: "Fresh Chicken (1kg)", product_price: 200, category: "Fresh & Frozen" },
    { product_id: 35, product_name: "Fresh Pork (1kg)", product_price: 280, category: "Fresh & Frozen" },
    { product_id: 36, product_name: "Fresh Beef (1kg)", product_price: 350, category: "Fresh & Frozen" },
    { product_id: 37, product_name: "Native Vegetables Basket", product_price: 250, category: "Fresh & Frozen" },
    { product_id: 38, product_name: "Bananas (1kg)", product_price: 60, category: "Fresh & Frozen" },
    { product_id: 39, product_name: "Mangoes (1kg)", product_price: 120, category: "Fresh & Frozen" },
    { product_id: 40, product_name: "Papaya (1kg)", product_price: 70, category: "Fresh & Frozen" },
    { product_id: 41, product_name: "Pineapple (Whole)", product_price: 90, category: "Fresh & Frozen" },
    { product_id: 42, product_name: "Coconut (Whole)", product_price: 50, category: "Fresh & Frozen" },
    { product_id: 44, product_name: "Camote (Sweet Potato, 1kg)", product_price: 80, category: "Fresh & Frozen" },

    // Desserts and Sweets
    { product_id: 45, product_name: "Ube Halaya (250g)", product_price: 180, category: "Desserts & Sweets" },
    { product_id: 46, product_name: "Leche Flan (Whole)", product_price: 250, category: "Desserts & Sweets" },
    { product_id: 47, product_name: "Bibingka (Whole)", product_price: 200, category: "Desserts & Sweets" },
    { product_id: 48, product_name: "Puto (Dozen)", product_price: 120, category: "Desserts & Sweets" },
    { product_id: 49, product_name: "Kakanin Sampler Pack", product_price: 300, category: "Desserts & Sweets" }
];

// Global variables tracking state across the POS application
let cart = [];
let transactions = [];
let receiptNumber = 1;
let totalSales = 0;
let productSales = {};


// DOM SCREEN & ELEMENT SELECTORS


// Main Application Screens
const welcomeScreen = document.getElementById("welcomeScreen");
const menuScreen = document.getElementById("menuScreen");
const checkoutScreen = document.getElementById("checkoutScreen");
const recordsScreen = document.getElementById("recordsScreen");

// Navigation Button References
const continueBtn = document.getElementById("continueBtn");
const checkoutMenuBtn = document.getElementById("checkoutMenuBtn");
const recordsMenuBtn = document.getElementById("recordsMenuBtn");
const exitBtn = document.getElementById("exitBtn");
const backButtons = document.querySelectorAll(".backMenu");

// Containers & Display Tables
const productList = document.getElementById("productList");
const cartTable = document.getElementById("cartTable");
const recordTable = document.getElementById("recordTable");

// Search Inputs & Filters
const searchProduct = document.getElementById("searchProduct");
const categoryFilter = document.getElementById("categoryFilter");
const searchRecord = document.getElementById("searchRecord");

// Subtotal, Discount & Total Elements
const subtotalAmount = document.getElementById("subtotalAmount");
const discountAmount = document.getElementById("discountAmount");
const totalAmount = document.getElementById("totalAmount");
const seniorDiscount = document.getElementById("seniorDiscount");
const pwdDiscount = document.getElementById("pwdDiscount");

// Payment Section Controls & Inputs
const paymentOptionsGroup = document.getElementById("paymentOptionsGroup");
const cashPayment = document.getElementById("cashPayment");
const cardPayment = document.getElementById("cardPayment");
const cancelPaymentBtn = document.getElementById("cancelPaymentBtn");
const cashSection = document.getElementById("cashSection");
const cardSection = document.getElementById("cardSection");
const cashInput = document.getElementById("cashInput");
const cardNumber = document.getElementById("cardNumber");
const changeAmount = document.getElementById("changeAmount");

// Receipt & Sales Dashboard Elements
const checkoutBtn = document.getElementById("checkoutBtn");
const receipt = document.getElementById("receipt");
const dailySales = document.getElementById("dailySales");
const mostPurchased = document.getElementById("mostPurchased");
const receiptModal = document.getElementById("receiptModal");
const receiptViewer = document.getElementById("receiptViewer");
const closeReceiptBtn = document.getElementById("closeReceiptBtn");


// NAVIGATION LOGIC & ROUTING


// Function: Switches active view screen by managing CSS 'active' classes
function showScreen(screen) {
    welcomeScreen.classList.remove("active");
    menuScreen.classList.remove("active");
    checkoutScreen.classList.remove("active");
    recordsScreen.classList.remove("active");

    screen.classList.add("active");
}

// Navigation Click Handlers
continueBtn.addEventListener("click", () => showScreen(menuScreen));
checkoutMenuBtn.addEventListener("click", () => showScreen(checkoutScreen));
recordsMenuBtn.addEventListener("click", () => {
    showScreen(recordsScreen);
    displayRecords();
    updateReports();
});
exitBtn.addEventListener("click", () => showScreen(welcomeScreen));

// Attach event listener to all back buttons returning to main menu
backButtons.forEach(button => {
    button.addEventListener("click", () => showScreen(menuScreen));
});


// PRODUCT CATALOG & SEARCH FILTERS


// Function: Dynamically renders product items into the menu UI grid
function loadProducts(products = groceryItems) {
    productList.innerHTML = "";

    products.forEach(product => {
        const card = document.createElement("div");
        card.className = "productCard";

        card.innerHTML = `
            <div class="productInfo">
                <h3>${product.product_name}</h3>
                <p>₱${product.product_price.toFixed(2)}</p>
            </div>
            <button onclick="addToCart(${product.product_id})">Add</button>
        `;

        productList.appendChild(card);
    });
}

// Function: Filters displayed products based on search keyword and category dropdown
function filterProducts() {
    const keyword = searchProduct.value.toLowerCase().trim();
    const selectedCategory = categoryFilter ? categoryFilter.value.toLowerCase().trim() : "all";

    const filtered = groceryItems.filter(product => {
        const matchesName = product.product_name.toLowerCase().includes(keyword);
        const productCategory = (product.category || "").toLowerCase().trim();
        const matchesCategory = selectedCategory === "all" || productCategory === selectedCategory;

        return matchesName && matchesCategory;
    });

    loadProducts(filtered);
}

// Event Listeners for Product Filtering
searchProduct.addEventListener("input", filterProducts);
if (categoryFilter) {
    categoryFilter.addEventListener("change", filterProducts);
}

// Function/Listener: Filters transaction history by receipt number search
searchRecord.addEventListener("input", function () {
    const keyword = this.value.toLowerCase().trim();
    const filtered = transactions.filter(record => {
        return record.receipt.toString().includes(keyword);
    });
    displayRecords(filtered);
});


// SHOPPING CART MANAGEMENT


// Function: Adds chosen item into active cart or increases quantity if already added
function addToCart(productId) {
    const product = groceryItems.find(p => p.product_id === productId);
    const cartItem = cart.find(item => item.product_id === productId);

    if (cartItem) {
        cartItem.quantity++;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    displayCart();
}

// Function: Renders cart list in table UI and recalculates subtotal
function displayCart() {
    cartTable.innerHTML = "";
    let subtotal = 0;

    cart.forEach(item => {
        const itemSubtotal = item.product_price * item.quantity;
        subtotal += itemSubtotal;

        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${item.product_name}</td>
            <td>₱${item.product_price.toFixed(2)}</td>
            <td>
                <div class="qtyButtons">
                    <button onclick="decreaseQty(${item.product_id})">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="increaseQty(${item.product_id})">+</button>
                </div>
            </td>
            <td>₱${itemSubtotal.toFixed(2)}</td>
            <td>
                <button class="removeBtn" onclick="removeItem(${item.product_id})">Remove</button>
            </td>
        `;
        cartTable.appendChild(row);
    });

    subtotalAmount.textContent = subtotal.toFixed(2);
    calculateTotals();
}

// Function: Computes discounts (Senior / PWD) and final payable total amount
function calculateTotals() {
    const subtotal = Number(subtotalAmount.textContent);
    let discountRate = 0;

    // Apply Senior and PWD discounts (20% each)
    if (seniorDiscount.checked) discountRate += 0.20;
    if (pwdDiscount.checked) discountRate += 0.20;

    const discount = subtotal * discountRate;
    const finalTotal = Math.max(0, subtotal - discount);

    discountAmount.textContent = discount.toFixed(2);
    totalAmount.textContent = finalTotal.toFixed(2);

    updateChange();
}

// Function: Increases item quantity from inside cart view
function increaseQty(productId) {
    const item = cart.find(product => product.product_id === productId);
    if (item) item.quantity++;
    displayCart();
}

// Function: Decreases item quantity or removes it if count drops to 0
function decreaseQty(productId) {
    const item = cart.find(product => product.product_id === productId);
    if (!item) return;

    item.quantity--;
    if (item.quantity <= 0) {
        cart = cart.filter(product => product.product_id !== productId);
    }
    displayCart();
}

// Function: Immediately removes item row from cart array
function removeItem(productId) {
    cart = cart.filter(product => product.product_id !== productId);
    displayCart();
}

// Discount Option Checkbox Listeners
seniorDiscount.addEventListener("change", calculateTotals);
pwdDiscount.addEventListener("change", calculateTotals);


// PAYMENT SELECTION & CONTROL LOGIC


// Function: Toggles input forms based on Cash or Card payment selection
function selectPaymentMode() {
    paymentOptionsGroup.style.display = "none";
    cancelPaymentBtn.style.display = "inline-block";

    if (cashPayment.checked) {
        cashSection.style.display = "flex";
        cardSection.style.display = "none";
    } else if (cardPayment.checked) {
        cashSection.style.display = "none";
        cardSection.style.display = "flex";
    }
}

// Function: Resets payment inputs back to original unselected state
function resetPaymentMode() {
    cashPayment.checked = false;
    cardPayment.checked = false;

    cashSection.style.display = "none";
    cardSection.style.display = "none";

    cancelPaymentBtn.style.display = "none";
    paymentOptionsGroup.style.display = "flex";

    cashInput.value = "";
    cardNumber.value = "";
    changeAmount.textContent = "0.00";
}

// Function: Calculates change live as cash amount is entered
function updateChange() {
    const total = Number(totalAmount.textContent);
    const cashPaid = Number(cashInput.value);

    if (cashPayment.checked && !isNaN(cashPaid) && cashPaid >= total) {
        changeAmount.textContent = (cashPaid - total).toFixed(2);
    } else {
        changeAmount.textContent = "0.00";
    }
}

// Event Listeners for Payment Section
cashPayment.addEventListener("change", selectPaymentMode);
cardPayment.addEventListener("change", selectPaymentMode);
cancelPaymentBtn.addEventListener("click", resetPaymentMode);
cashInput.addEventListener("input", updateChange);


// CHECKOUT & RECEIPT GENERATION


// Helper Function: Formats transaction data into printable receipt text
function formatReceiptText(tx) {
    let text = "========== STORE POS ==========\n\n";
    text += "Receipt #: " + tx.receipt + "\n";
    text += "Date: " + tx.date + "\n";
    text += "Payment Method: " + tx.paymentMethod + "\n\n";

    tx.products.forEach(p => {
        text += p.name + "\n";
        text += p.qty + " x ₱" + p.price.toFixed(2) + " = ₱" + p.subtotal.toFixed(2) + "\n\n";
    });

    text += "-------------------------------\n";
    text += "SUBTOTAL : ₱" + (tx.subtotal || 0).toFixed(2) + "\n";
    text += "DISCOUNT : ₱" + (tx.discount || 0).toFixed(2) + "\n";
    text += "TOTAL    : ₱" + tx.total.toFixed(2) + "\n";
    text += "PAID     : ₱" + tx.cash.toFixed(2) + "\n";
    text += "CHANGE   : ₱" + tx.change.toFixed(2) + "\n";
    text += "===============================\n";
    text += "Thank You!";

    return text;
}

// Function: Main checkout processor executed when "Checkout" button is clicked
function checkout() {
    // Ensure cart is not empty
    if (cart.length === 0) {
        alert("Cart is empty.");
        return;
    }

    // Ensure payment method is chosen
    if (!cashPayment.checked && !cardPayment.checked) {
        alert("Please select a payment method.");
        return;
    }

    const total = Number(totalAmount.textContent);
    let cashPaid = 0;
    let changeGiven = 0;

    // Process Cash Payment: Validate amount paid
    if (cashPayment.checked) {
        cashPaid = Number(cashInput.value);
        if (isNaN(cashPaid) || cashPaid < total) {
            alert("Insufficient cash.");
            return;
        }
        changeGiven = cashPaid - total;

    // Process Card Payment: Validate card number
    } else if (cardPayment.checked) {
        if (!cardNumber.value.trim()) {
            alert("Please enter a Card Number.");
            return;
        }
    }

    // Create immutable Transaction Record object
    const now = new Date();
    const transaction = {
        receipt: receiptNumber++,
        date: now.toLocaleString(),
        items: cart.reduce((sum, item) => sum + item.quantity, 0),
        subtotal: Number(subtotalAmount.textContent),
        discount: Number(discountAmount.textContent),
        total: total,
        cash: cashPaid,
        change: changeGiven,
        paymentMethod: cashPayment.checked ? "Cash" : "Card",
        products: cart.map(item => ({
            name: item.product_name,
            price: item.product_price,
            qty: item.quantity,
            subtotal: item.product_price * item.quantity
        }))
    };

    // Push transaction record to history & increment total sales tracker
    transactions.push(transaction);
    totalSales += total;

    // Accumulate sold item quantities for top product statistics
    cart.forEach(item => {
        productSales[item.product_name] = (productSales[item.product_name] || 0) + item.quantity;
    });

    // Display compiled receipt text to UI container
    receipt.textContent = formatReceiptText(transaction);

    // Clear active cart and reset form inputs for next order
    cart = [];
    seniorDiscount.checked = false;
    pwdDiscount.checked = false;
    resetPaymentMode();

    // Refresh user interface, records table, and analytics metrics
    displayCart();
    displayRecords();
    updateReports();
}

// Bind Checkout function to button click
checkoutBtn.addEventListener("click", checkout);


// RECORDS & REPORTING DASHBOARD


// Function: Renders all previous transaction logs into history records table
function displayRecords(recordsList = transactions) {
    recordTable.innerHTML = "";

    recordsList.forEach(rec => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>#${rec.receipt}</td>
            <td>${rec.date}</td>
            <td>${rec.items}</td>
            <td>₱${rec.total.toFixed(2)}</td>
            <td>
                <button class="view-receipt-btn" onclick="openReceiptModal(${rec.receipt})">See Receipt</button>
            </td>
        `;
        recordTable.appendChild(row);
    });
}

// Function: Opens modal overlay to show detailed historical transaction receipt
function openReceiptModal(receiptNum) {
    const tx = transactions.find(t => t.receipt === Number(receiptNum));
    if (!tx) {
        alert("Receipt details not found.");
        return;
    }

    const modal = document.getElementById("receiptModal");
    const viewer = document.getElementById("receiptViewer");

    if (viewer) {
        viewer.textContent = formatReceiptText(tx);
    }
    
    if (modal) {
        modal.classList.add("active");
        modal.style.display = "flex";
    }
}

// Function: Closes receipt modal window
function closeReceiptModal() {
    const modal = document.getElementById("receiptModal");
    if (modal) {
        modal.classList.remove("active");
        modal.style.display = "none";
    }
}

// Explicitly attach helper functions to window object for inline HTML triggers
window.addToCart = addToCart;
window.increaseQty = increaseQty;
window.decreaseQty = decreaseQty;
window.removeItem = removeItem;
window.openReceiptModal = openReceiptModal;
window.closeReceiptModal = closeReceiptModal;

// Bind modal close buttons
if (closeReceiptBtn) {
    closeReceiptBtn.addEventListener("click", closeReceiptModal);
}

if (receiptModal) {
    receiptModal.addEventListener("click", (e) => {
        if (e.target === receiptModal) closeReceiptModal();
    });
}

// Function: Computes cumulative sales total and identifies the most purchased product
function updateReports() {
    if (dailySales) {
        dailySales.textContent = totalSales.toFixed(2);
    }

    if (mostPurchased) {
        let maxQty = 0;
        let topProduct = "None";

        for (const [name, qty] of Object.entries(productSales)) {
            if (qty > maxQty) {
                maxQty = qty;
                topProduct = `${name} (${qty})`;
            }
        }
        mostPurchased.textContent = topProduct;
    }
}

// Initial loading call when page first opens
loadProducts();